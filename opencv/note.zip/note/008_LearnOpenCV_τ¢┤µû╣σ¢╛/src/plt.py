import matplotlib.pyplot as plt
plt.plot([1, 2], [3, 4, 7])
plt.show()
